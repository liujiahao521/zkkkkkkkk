# API 文档

## 1. 餐食识别

```http
POST /api/foods/recognize
```

请求体：

```json
{
  "userId": 10001,
  "mealType": "LUNCH",
  "imageUrl": "https://example.com/lunch.jpg",
  "remark": "米饭、鸡胸肉、西兰花"
}
```

## 2. 保存识别结果

```http
POST /api/records/from-recognition
```

请求体：

```json
{
  "userId": 10001,
  "mealType": "LUNCH",
  "foods": [
    {
      "name": "鸡胸肉",
      "weightGram": 150,
      "calorie": 248,
      "protein": 46.5,
      "fat": 5.4,
      "carbohydrate": 0
    }
  ]
}
```

## 3. 今日饮食记录

```http
GET /api/records/today?userId=10001
```

## 4. 今日看板

```http
GET /api/dashboard/today?userId=10001
```

## 5. Agent 问答

```http
POST /api/agent/ask
```

请求体：

```json
{
  "userId": 10001,
  "question": "我今天晚上还能吃多少？"
}
```

## 6. Token 统计

```http
GET /api/token-usage/summary?userId=10001
```

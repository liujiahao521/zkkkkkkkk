# 技术架构说明

## 一、整体架构

```mermaid
flowchart LR
    A[Web 演示页面] --> B[Spring Boot Controller]
    B --> C[业务服务层]
    C --> D[AI Client]
    C --> E[JDBC Repository]
    D --> F[MiMo API / Mock AI]
    E --> G[H2 / MySQL]
```

## 二、核心模块

| 模块 | 说明 |
|---|---|
| FoodRecognitionService | 负责餐食识别、AI 调用、结构化食物数据生成 |
| DietRecordService | 负责饮食记录落库与查询 |
| DashboardService | 负责今日摄入、热量缺口和营养摄入统计 |
| AgentService | 负责结合用户饮食上下文生成 Agent 问答结果 |
| TokenUsageService | 负责记录模型调用 token、耗时和调用场景 |
| MimoAiClient | 负责真实模型调用与 Mock 降级 |

## 三、AI 调用链路

1. 用户上传图片或填写餐食备注。
2. 后端构建 system prompt 和 user prompt。
3. MimoAiClient 判断是否启用真实模型。
4. 若配置 API Key，则请求 `/chat/completions`。
5. 若未配置或调用失败，则自动降级 Mock。
6. 业务服务解析结果并返回结构化食物数据。
7. TokenUsageService 记录调用日志。

## 四、数据表

- `user_health_profile`：用户健康档案
- `diet_record`：饮食记录
- `token_usage_log`：Token 使用日志

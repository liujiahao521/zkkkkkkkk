CREATE TABLE IF NOT EXISTS diet_record (
    id VARCHAR(64) PRIMARY KEY,
    user_id BIGINT NOT NULL,
    meal_type VARCHAR(32) NOT NULL,
    food_name VARCHAR(100) NOT NULL,
    weight_gram DECIMAL(10,2) NOT NULL,
    calorie DECIMAL(10,2) NOT NULL,
    protein DECIMAL(10,2) NOT NULL,
    fat DECIMAL(10,2) NOT NULL,
    carbohydrate DECIMAL(10,2) NOT NULL,
    record_time TIMESTAMP NOT NULL,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_health_profile (
    user_id BIGINT PRIMARY KEY,
    nickname VARCHAR(50) NOT NULL,
    gender VARCHAR(16),
    height_cm DECIMAL(10,2),
    weight_kg DECIMAL(10,2),
    target_weight_kg DECIMAL(10,2),
    daily_calorie_target DECIMAL(10,2) NOT NULL,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS token_usage_log (
    id VARCHAR(64) PRIMARY KEY,
    user_id BIGINT NOT NULL,
    scene VARCHAR(64) NOT NULL,
    model_name VARCHAR(100) NOT NULL,
    prompt_tokens INT NOT NULL,
    completion_tokens INT NOT NULL,
    total_tokens INT NOT NULL,
    latency_ms BIGINT NOT NULL,
    mock_flag BOOLEAN NOT NULL,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

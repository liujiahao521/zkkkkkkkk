package com.example.dietagent.service;

import com.example.dietagent.ai.AiResult;
import com.example.dietagent.ai.MimoAiClient;
import com.example.dietagent.dto.RecognizeFoodRequest;
import com.example.dietagent.dto.RecognizeFoodResponse;
import com.example.dietagent.model.FoodItem;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class FoodRecognitionService {
    private final MimoAiClient aiClient;
    private final TokenUsageService tokenUsageService;

    public FoodRecognitionService(MimoAiClient aiClient, TokenUsageService tokenUsageService) {
        this.aiClient = aiClient;
        this.tokenUsageService = tokenUsageService;
    }

    public RecognizeFoodResponse recognize(RecognizeFoodRequest request) {
        String systemPrompt = "你是一名营养识别助手，请根据用户上传的餐食图片和备注，输出食物名称、克重、热量和营养成分。";
        String userPrompt = "图片地址：" + request.imageUrl() + "，用户备注：" + request.remark() + "，餐次：" + request.mealType();
        AiResult aiResult = aiClient.chat("FOOD_RECOGNITION", systemPrompt, userPrompt);
        tokenUsageService.record(request.userId(), "FOOD_RECOGNITION", aiResult);

        List<FoodItem> foods = buildDemoFoods(request.remark());
        return new RecognizeFoodResponse(
                UUID.randomUUID().toString(),
                "SUCCESS",
                aiResult.modelName(),
                aiResult.mockFlag(),
                foods,
                sum(foods, "calorie"),
                sum(foods, "protein"),
                sum(foods, "fat"),
                sum(foods, "carbohydrate"),
                aiResult.content()
        );
    }

    private List<FoodItem> buildDemoFoods(String remark) {
        String text = remark == null ? "" : remark;
        if (text.contains("面") || text.contains("饺") || text.contains("包子")) {
            return List.of(
                    new FoodItem("牛肉面", new BigDecimal("420"), new BigDecimal("560"), new BigDecimal("28"), new BigDecimal("16"), new BigDecimal("78")),
                    new FoodItem("青菜", new BigDecimal("80"), new BigDecimal("28"), new BigDecimal("2"), new BigDecimal("0.4"), new BigDecimal("5"))
            );
        }
        return List.of(
                new FoodItem("米饭", new BigDecimal("180"), new BigDecimal("210"), new BigDecimal("4.8"), new BigDecimal("0.6"), new BigDecimal("47")),
                new FoodItem("鸡胸肉", new BigDecimal("150"), new BigDecimal("248"), new BigDecimal("46.5"), new BigDecimal("5.4"), new BigDecimal("0")),
                new FoodItem("西兰花", new BigDecimal("120"), new BigDecimal("40"), new BigDecimal("3.4"), new BigDecimal("0.5"), new BigDecimal("7.2"))
        );
    }

    private BigDecimal sum(List<FoodItem> foods, String field) {
        return foods.stream().map(food -> switch (field) {
            case "calorie" -> food.calorie();
            case "protein" -> food.protein();
            case "fat" -> food.fat();
            case "carbohydrate" -> food.carbohydrate();
            default -> BigDecimal.ZERO;
        }).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}

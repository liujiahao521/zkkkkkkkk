package com.example.dietagent.repository;

import com.example.dietagent.model.UserHealthProfile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class UserHealthProfileRepository {
    private final JdbcTemplate jdbcTemplate;

    public UserHealthProfileRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public UserHealthProfile findByUserId(Long userId) {
        return jdbcTemplate.query("""
                SELECT user_id, nickname, gender, height_cm, weight_kg, target_weight_kg, daily_calorie_target
                FROM user_health_profile
                WHERE user_id = ?
                """, rs -> {
            if (rs.next()) {
                return new UserHealthProfile(
                        rs.getLong("user_id"),
                        rs.getString("nickname"),
                        rs.getString("gender"),
                        rs.getBigDecimal("height_cm"),
                        rs.getBigDecimal("weight_kg"),
                        rs.getBigDecimal("target_weight_kg"),
                        rs.getBigDecimal("daily_calorie_target")
                );
            }
            return new UserHealthProfile(userId, "默认用户", "UNKNOWN", BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("1800"));
        }, userId);
    }
}

package com.example.dietagent.dto;

import com.example.dietagent.model.FoodItem;
import java.math.BigDecimal;
import java.util.List;

public record RecognizeFoodResponse(
        String taskId,
        String status,
        String modelName,
        boolean mockFlag,
        List<FoodItem> foods,
        BigDecimal totalCalorie,
        BigDecimal totalProtein,
        BigDecimal totalFat,
        BigDecimal totalCarbohydrate,
        String aiSummary
) {
}

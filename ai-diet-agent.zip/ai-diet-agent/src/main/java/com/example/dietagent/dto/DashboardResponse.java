package com.example.dietagent.dto;

import com.example.dietagent.model.DietRecord;
import java.math.BigDecimal;
import java.util.List;

public record DashboardResponse(
        Long userId,
        BigDecimal dailyCalorieTarget,
        BigDecimal intakeCalorie,
        BigDecimal remainingCalorie,
        BigDecimal protein,
        BigDecimal fat,
        BigDecimal carbohydrate,
        String level,
        String suggestion,
        List<DietRecord> records
) {
}

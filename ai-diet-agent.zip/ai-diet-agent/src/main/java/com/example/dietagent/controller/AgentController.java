package com.example.dietagent.controller;

import com.example.dietagent.common.ApiResponse;
import com.example.dietagent.dto.AgentAskRequest;
import com.example.dietagent.dto.AgentAskResponse;
import com.example.dietagent.service.AgentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentService agentService;

    public AgentController(AgentService agentService) {
        this.agentService = agentService;
    }

    @PostMapping("/ask")
    public ApiResponse<AgentAskResponse> ask(@RequestBody @Valid AgentAskRequest request) {
        return ApiResponse.ok(agentService.ask(request));
    }
}

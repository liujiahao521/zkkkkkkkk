package com.example.dietagent.controller;

import com.example.dietagent.common.ApiResponse;
import com.example.dietagent.dto.RecognizeFoodRequest;
import com.example.dietagent.dto.RecognizeFoodResponse;
import com.example.dietagent.service.FoodRecognitionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/foods")
public class FoodController {
    private final FoodRecognitionService foodRecognitionService;

    public FoodController(FoodRecognitionService foodRecognitionService) {
        this.foodRecognitionService = foodRecognitionService;
    }

    @PostMapping("/recognize")
    public ApiResponse<RecognizeFoodResponse> recognize(@RequestBody @Valid RecognizeFoodRequest request) {
        return ApiResponse.ok(foodRecognitionService.recognize(request));
    }
}

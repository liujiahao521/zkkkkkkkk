package com.example.dietagent.service;

import com.example.dietagent.dto.DashboardResponse;
import com.example.dietagent.model.DietRecord;
import com.example.dietagent.model.UserHealthProfile;
import com.example.dietagent.repository.DietRecordRepository;
import com.example.dietagent.repository.UserHealthProfileRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class DashboardService {
    private final DietRecordRepository dietRecordRepository;
    private final UserHealthProfileRepository profileRepository;

    public DashboardService(DietRecordRepository dietRecordRepository, UserHealthProfileRepository profileRepository) {
        this.dietRecordRepository = dietRecordRepository;
        this.profileRepository = profileRepository;
    }

    public DashboardResponse today(Long userId) {
        UserHealthProfile profile = profileRepository.findByUserId(userId);
        List<DietRecord> records = dietRecordRepository.findToday(userId);
        BigDecimal calorie = sum(records, "calorie");
        BigDecimal remaining = profile.dailyCalorieTarget().subtract(calorie);
        String level = remaining.compareTo(new BigDecimal("500")) > 0 ? "充足" : remaining.compareTo(BigDecimal.ZERO) >= 0 ? "偏紧" : "超标";
        String suggestion = switch (level) {
            case "充足" -> "今天热量额度比较充足，晚餐可以选择高蛋白食物和适量主食。";
            case "偏紧" -> "今天剩余额度不多，建议晚餐以蔬菜、蛋白质为主，减少油脂和精制碳水。";
            default -> "今天摄入已经超出目标，建议后续减少夜宵并增加轻量运动。";
        };
        return new DashboardResponse(
                userId,
                profile.dailyCalorieTarget(),
                calorie,
                remaining,
                sum(records, "protein"),
                sum(records, "fat"),
                sum(records, "carbohydrate"),
                level,
                suggestion,
                records
        );
    }

    private BigDecimal sum(List<DietRecord> records, String field) {
        return records.stream().map(record -> switch (field) {
            case "calorie" -> record.calorie();
            case "protein" -> record.protein();
            case "fat" -> record.fat();
            case "carbohydrate" -> record.carbohydrate();
            default -> BigDecimal.ZERO;
        }).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}

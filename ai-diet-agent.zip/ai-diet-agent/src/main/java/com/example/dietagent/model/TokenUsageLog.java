package com.example.dietagent.model;

import java.time.LocalDateTime;

public record TokenUsageLog(
        String id,
        Long userId,
        String scene,
        String modelName,
        int promptTokens,
        int completionTokens,
        int totalTokens,
        long latencyMs,
        boolean mockFlag,
        LocalDateTime createTime
) {
}

package com.example.dietagent.ai;

public record AiResult(
        String content,
        String modelName,
        int promptTokens,
        int completionTokens,
        int totalTokens,
        long latencyMs,
        boolean mockFlag
) {
}

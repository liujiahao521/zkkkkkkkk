package com.example.dietagent.ai;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class MimoAiClient {
    private final boolean enabled;
    private final String baseUrl;
    private final String apiKey;
    private final String model;

    public MimoAiClient(
            @Value("${ai.mimo.enabled:false}") boolean enabled,
            @Value("${ai.mimo.base-url}") String baseUrl,
            @Value("${ai.mimo.api-key:}") String apiKey,
            @Value("${ai.mimo.model:MiMo-V2.5}") String model) {
        this.enabled = enabled;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
    }

    public AiResult chat(String scene, String systemPrompt, String userPrompt) {
        if (!enabled || !StringUtils.hasText(apiKey)) {
            return mock(scene, userPrompt);
        }

        Instant start = Instant.now();
        try {
            RestClient client = RestClient.builder()
                    .baseUrl(baseUrl)
                    .defaultHeader("Authorization", "Bearer " + apiKey)
                    .defaultHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .build();

            Map<String, Object> body = Map.of(
                    "model", model,
                    "messages", List.of(
                            Map.of("role", "system", "content", systemPrompt),
                            Map.of("role", "user", "content", userPrompt)
                    ),
                    "temperature", 0.4
            );

            Map response = client.post()
                    .uri("/chat/completions")
                    .body(body)
                    .retrieve()
                    .body(Map.class);

            String content = extractContent(response);
            int promptTokens = extractInt(response, "prompt_tokens", estimateTokens(systemPrompt + userPrompt));
            int completionTokens = extractInt(response, "completion_tokens", estimateTokens(content));
            int totalTokens = extractInt(response, "total_tokens", promptTokens + completionTokens);
            long latency = Duration.between(start, Instant.now()).toMillis();
            return new AiResult(content, model, promptTokens, completionTokens, totalTokens, latency, false);
        } catch (Exception ex) {
            return mock(scene, userPrompt + "\n真实模型调用失败，已自动降级 Mock：" + ex.getMessage());
        }
    }

    private String extractContent(Map response) {
        if (response == null) {
            return "模型未返回内容";
        }
        Object choicesObj = response.get("choices");
        if (choicesObj instanceof List<?> choices && !choices.isEmpty()) {
            Object first = choices.get(0);
            if (first instanceof Map<?, ?> choiceMap) {
                Object messageObj = choiceMap.get("message");
                if (messageObj instanceof Map<?, ?> messageMap) {
                    Object content = messageMap.get("content");
                    if (content != null) {
                        return content.toString();
                    }
                }
            }
        }
        return response.toString();
    }

    private int extractInt(Map response, String key, int fallback) {
        if (response == null || !(response.get("usage") instanceof Map<?, ?> usage)) {
            return fallback;
        }
        Object value = usage.get(key);
        if (value instanceof Number number) {
            return number.intValue();
        }
        return fallback;
    }

    private AiResult mock(String scene, String prompt) {
        long latency = ThreadLocalRandom.current().nextLong(180, 680);
        int promptTokens = estimateTokens(prompt);
        int completionTokens = ThreadLocalRandom.current().nextInt(180, 360);
        String content = switch (scene) {
            case "FOOD_RECOGNITION" -> "识别结果：图片中包含米饭、鸡胸肉和青菜，整体属于高蛋白、中等碳水、低脂肪的一餐。";
            case "DIET_AGENT" -> "根据今天已记录的饮食，你还可以摄入约 900~1100 千卡。晚餐建议选择鸡胸肉、鱼肉、蔬菜和少量主食，避免高糖饮料和油炸食品。";
            case "WEEKLY_REPORT" -> "本周饮食整体较稳定，蛋白质摄入较好，但晚餐碳水波动偏大，建议固定晚餐主食克重并增加蔬菜比例。";
            default -> "这是 Mock AI 返回结果，可通过配置 MIMO_API_KEY 切换为真实模型调用。";
        };
        return new AiResult(content, model + "-mock", promptTokens, completionTokens, promptTokens + completionTokens, latency, true);
    }

    private int estimateTokens(String text) {
        if (text == null || text.isBlank()) {
            return 0;
        }
        return Math.max(20, text.length() / 2);
    }
}

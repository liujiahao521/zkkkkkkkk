package com.example.dietagent.service;

import com.example.dietagent.ai.AiResult;
import com.example.dietagent.dto.TokenSummaryResponse;
import com.example.dietagent.model.TokenUsageLog;
import com.example.dietagent.repository.TokenUsageRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class TokenUsageService {
    private final TokenUsageRepository tokenUsageRepository;

    public TokenUsageService(TokenUsageRepository tokenUsageRepository) {
        this.tokenUsageRepository = tokenUsageRepository;
    }

    public void record(Long userId, String scene, AiResult result) {
        tokenUsageRepository.save(new TokenUsageLog(
                UUID.randomUUID().toString(),
                userId,
                scene,
                result.modelName(),
                result.promptTokens(),
                result.completionTokens(),
                result.totalTokens(),
                result.latencyMs(),
                result.mockFlag(),
                LocalDateTime.now()
        ));
    }

    public TokenSummaryResponse summary(Long userId) {
        List<TokenUsageLog> logs = tokenUsageRepository.findRecent(userId, 20);
        int requestCount = logs.size();
        int promptTokens = logs.stream().mapToInt(TokenUsageLog::promptTokens).sum();
        int completionTokens = logs.stream().mapToInt(TokenUsageLog::completionTokens).sum();
        int totalTokens = logs.stream().mapToInt(TokenUsageLog::totalTokens).sum();
        long avgLatency = logs.stream().mapToLong(TokenUsageLog::latencyMs).sum() / Math.max(1, requestCount);
        return new TokenSummaryResponse(userId, requestCount, totalTokens, promptTokens, completionTokens, avgLatency, logs);
    }
}

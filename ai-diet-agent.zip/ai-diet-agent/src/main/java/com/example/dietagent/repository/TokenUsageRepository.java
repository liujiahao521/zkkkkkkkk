package com.example.dietagent.repository;

import com.example.dietagent.model.TokenUsageLog;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TokenUsageRepository {
    private final JdbcTemplate jdbcTemplate;

    public TokenUsageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(TokenUsageLog log) {
        jdbcTemplate.update("""
                INSERT INTO token_usage_log(id, user_id, scene, model_name, prompt_tokens, completion_tokens, total_tokens, latency_ms, mock_flag)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                log.id(), log.userId(), log.scene(), log.modelName(), log.promptTokens(), log.completionTokens(),
                log.totalTokens(), log.latencyMs(), log.mockFlag());
    }

    public List<TokenUsageLog> findRecent(Long userId, int limit) {
        return jdbcTemplate.query("""
                SELECT id, user_id, scene, model_name, prompt_tokens, completion_tokens, total_tokens, latency_ms, mock_flag, create_time
                FROM token_usage_log
                WHERE user_id = ?
                ORDER BY create_time DESC
                LIMIT ?
                """,
                (rs, rowNum) -> new TokenUsageLog(
                        rs.getString("id"),
                        rs.getLong("user_id"),
                        rs.getString("scene"),
                        rs.getString("model_name"),
                        rs.getInt("prompt_tokens"),
                        rs.getInt("completion_tokens"),
                        rs.getInt("total_tokens"),
                        rs.getLong("latency_ms"),
                        rs.getBoolean("mock_flag"),
                        rs.getTimestamp("create_time").toLocalDateTime()
                ), userId, limit);
    }
}

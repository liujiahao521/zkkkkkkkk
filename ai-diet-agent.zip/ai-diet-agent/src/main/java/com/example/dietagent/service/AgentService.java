package com.example.dietagent.service;

import com.example.dietagent.ai.AiResult;
import com.example.dietagent.ai.MimoAiClient;
import com.example.dietagent.dto.AgentAskRequest;
import com.example.dietagent.dto.AgentAskResponse;
import com.example.dietagent.dto.DashboardResponse;
import org.springframework.stereotype.Service;

@Service
public class AgentService {
    private final DashboardService dashboardService;
    private final MimoAiClient aiClient;
    private final TokenUsageService tokenUsageService;

    public AgentService(DashboardService dashboardService, MimoAiClient aiClient, TokenUsageService tokenUsageService) {
        this.dashboardService = dashboardService;
        this.aiClient = aiClient;
        this.tokenUsageService = tokenUsageService;
    }

    public AgentAskResponse ask(AgentAskRequest request) {
        DashboardResponse dashboard = dashboardService.today(request.userId());
        String systemPrompt = "你是一名饮食健康管理 Agent，需要结合用户当天饮食记录、目标热量和剩余热量，给出可执行建议。";
        String userPrompt = "用户问题：" + request.question()
                + "\n今日目标热量：" + dashboard.dailyCalorieTarget()
                + "\n已摄入热量：" + dashboard.intakeCalorie()
                + "\n剩余热量：" + dashboard.remainingCalorie()
                + "\n蛋白质：" + dashboard.protein()
                + "\n脂肪：" + dashboard.fat()
                + "\n碳水：" + dashboard.carbohydrate();
        AiResult result = aiClient.chat("DIET_AGENT", systemPrompt, userPrompt);
        tokenUsageService.record(request.userId(), "DIET_AGENT", result);
        return new AgentAskResponse(result.content(), "DIET_AGENT", result.modelName(), result.totalTokens(), result.latencyMs(), result.mockFlag());
    }
}

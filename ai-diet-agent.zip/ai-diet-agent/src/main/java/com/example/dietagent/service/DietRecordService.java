package com.example.dietagent.service;

import com.example.dietagent.dto.SaveRecognitionRequest;
import com.example.dietagent.model.DietRecord;
import com.example.dietagent.model.FoodItem;
import com.example.dietagent.repository.DietRecordRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class DietRecordService {
    private final DietRecordRepository dietRecordRepository;

    public DietRecordService(DietRecordRepository dietRecordRepository) {
        this.dietRecordRepository = dietRecordRepository;
    }

    public List<DietRecord> saveFromRecognition(SaveRecognitionRequest request) {
        List<DietRecord> records = request.foods().stream()
                .map(food -> toRecord(request.userId(), request.mealType(), food))
                .toList();
        records.forEach(dietRecordRepository::save);
        return records;
    }

    public List<DietRecord> today(Long userId) {
        return dietRecordRepository.findToday(userId);
    }

    private DietRecord toRecord(Long userId, String mealType, FoodItem food) {
        return new DietRecord(
                UUID.randomUUID().toString(),
                userId,
                mealType,
                food.name(),
                food.weightGram(),
                food.calorie(),
                food.protein(),
                food.fat(),
                food.carbohydrate(),
                LocalDateTime.now()
        );
    }
}

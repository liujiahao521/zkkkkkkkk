package com.example.dietagent.controller;

import com.example.dietagent.common.ApiResponse;
import com.example.dietagent.dto.TokenSummaryResponse;
import com.example.dietagent.service.TokenUsageService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/token-usage")
public class TokenUsageController {
    private final TokenUsageService tokenUsageService;

    public TokenUsageController(TokenUsageService tokenUsageService) {
        this.tokenUsageService = tokenUsageService;
    }

    @GetMapping("/summary")
    public ApiResponse<TokenSummaryResponse> summary(@RequestParam Long userId) {
        return ApiResponse.ok(tokenUsageService.summary(userId));
    }
}

package com.example.dietagent.dto;

import com.example.dietagent.model.FoodItem;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public record SaveRecognitionRequest(
        @NotNull Long userId,
        @NotBlank String mealType,
        @NotEmpty List<FoodItem> foods
) {
}

package com.example.dietagent.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AgentAskRequest(
        @NotNull Long userId,
        @NotBlank String question
) {
}

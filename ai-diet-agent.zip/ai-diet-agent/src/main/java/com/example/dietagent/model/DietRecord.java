package com.example.dietagent.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record DietRecord(
        String id,
        Long userId,
        String mealType,
        String foodName,
        BigDecimal weightGram,
        BigDecimal calorie,
        BigDecimal protein,
        BigDecimal fat,
        BigDecimal carbohydrate,
        LocalDateTime recordTime
) {
}

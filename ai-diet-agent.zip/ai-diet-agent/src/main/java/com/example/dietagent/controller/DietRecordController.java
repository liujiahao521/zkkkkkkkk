package com.example.dietagent.controller;

import com.example.dietagent.common.ApiResponse;
import com.example.dietagent.dto.SaveRecognitionRequest;
import com.example.dietagent.model.DietRecord;
import com.example.dietagent.service.DietRecordService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/records")
public class DietRecordController {
    private final DietRecordService dietRecordService;

    public DietRecordController(DietRecordService dietRecordService) {
        this.dietRecordService = dietRecordService;
    }

    @PostMapping("/from-recognition")
    public ApiResponse<List<DietRecord>> saveFromRecognition(@RequestBody @Valid SaveRecognitionRequest request) {
        return ApiResponse.ok(dietRecordService.saveFromRecognition(request));
    }

    @GetMapping("/today")
    public ApiResponse<List<DietRecord>> today(@RequestParam Long userId) {
        return ApiResponse.ok(dietRecordService.today(userId));
    }
}

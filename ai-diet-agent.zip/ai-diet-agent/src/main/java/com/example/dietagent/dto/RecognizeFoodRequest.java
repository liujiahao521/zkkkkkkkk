package com.example.dietagent.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RecognizeFoodRequest(
        @NotNull Long userId,
        @NotBlank String mealType,
        String imageUrl,
        String remark
) {
}

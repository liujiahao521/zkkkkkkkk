package com.example.dietagent.dto;

public record AgentAskResponse(
        String answer,
        String scene,
        String modelName,
        int totalTokens,
        long latencyMs,
        boolean mockFlag
) {
}

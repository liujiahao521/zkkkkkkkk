package com.example.dietagent.model;

import java.math.BigDecimal;

public record FoodItem(
        String name,
        BigDecimal weightGram,
        BigDecimal calorie,
        BigDecimal protein,
        BigDecimal fat,
        BigDecimal carbohydrate
) {
}

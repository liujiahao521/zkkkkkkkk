package com.example.dietagent.dto;

import com.example.dietagent.model.TokenUsageLog;
import java.util.List;

public record TokenSummaryResponse(
        Long userId,
        int requestCount,
        int totalTokens,
        int promptTokens,
        int completionTokens,
        long avgLatencyMs,
        List<TokenUsageLog> recentLogs
) {
}

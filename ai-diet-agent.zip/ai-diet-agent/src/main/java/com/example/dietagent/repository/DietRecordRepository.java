package com.example.dietagent.repository;

import com.example.dietagent.model.DietRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class DietRecordRepository {
    private final JdbcTemplate jdbcTemplate;

    public DietRecordRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(DietRecord record) {
        jdbcTemplate.update("""
                INSERT INTO diet_record(id, user_id, meal_type, food_name, weight_gram, calorie, protein, fat, carbohydrate, record_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                record.id(), record.userId(), record.mealType(), record.foodName(), record.weightGram(),
                record.calorie(), record.protein(), record.fat(), record.carbohydrate(), Timestamp.valueOf(record.recordTime()));
    }

    public List<DietRecord> findToday(Long userId) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = today.plusDays(1).atStartOfDay();
        return jdbcTemplate.query("""
                SELECT id, user_id, meal_type, food_name, weight_gram, calorie, protein, fat, carbohydrate, record_time
                FROM diet_record
                WHERE user_id = ? AND record_time >= ? AND record_time < ?
                ORDER BY record_time DESC
                """,
                (rs, rowNum) -> new DietRecord(
                        rs.getString("id"),
                        rs.getLong("user_id"),
                        rs.getString("meal_type"),
                        rs.getString("food_name"),
                        rs.getBigDecimal("weight_gram"),
                        rs.getBigDecimal("calorie"),
                        rs.getBigDecimal("protein"),
                        rs.getBigDecimal("fat"),
                        rs.getBigDecimal("carbohydrate"),
                        rs.getTimestamp("record_time").toLocalDateTime()
                ), userId, Timestamp.valueOf(start), Timestamp.valueOf(end));
    }
}

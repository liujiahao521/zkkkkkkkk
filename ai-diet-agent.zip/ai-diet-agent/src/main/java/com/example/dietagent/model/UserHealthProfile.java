package com.example.dietagent.model;

import java.math.BigDecimal;

public record UserHealthProfile(
        Long userId,
        String nickname,
        String gender,
        BigDecimal heightCm,
        BigDecimal weightKg,
        BigDecimal targetWeightKg,
        BigDecimal dailyCalorieTarget
) {
}

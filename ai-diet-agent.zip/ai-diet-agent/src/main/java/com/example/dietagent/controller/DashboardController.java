package com.example.dietagent.controller;

import com.example.dietagent.common.ApiResponse;
import com.example.dietagent.dto.DashboardResponse;
import com.example.dietagent.service.DashboardService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/today")
    public ApiResponse<DashboardResponse> today(@RequestParam Long userId) {
        return ApiResponse.ok(dashboardService.today(userId));
    }
}

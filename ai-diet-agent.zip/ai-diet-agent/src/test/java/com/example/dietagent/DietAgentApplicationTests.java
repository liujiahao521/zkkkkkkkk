package com.example.dietagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DietAgentApplicationTests {
    @Test
    void contextLoads() {
    }
}

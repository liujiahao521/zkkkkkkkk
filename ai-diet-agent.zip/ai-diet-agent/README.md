# 智能饮食识别与热量管理 Agent

一个基于 **Spring Boot 3 + Java 17** 的 AI 饮食助手演示项目，围绕“拍照识别食物、热量估算、饮食记录、热量缺口计算、健康建议生成、Token 使用统计”构建完整业务闭环。项目可用于 AI 应用开发学习、简历展示、Agent 能力证明和 GitHub 项目展示。

> 默认使用本地 Mock AI，可直接运行；配置 `MIMO_API_KEY` 后可切换为真实大模型接口调用。

---

## 项目亮点

- **AI 食物识别**：根据餐食图片地址/描述模拟识别食物名称、克重、热量和营养成分。
- **热量缺口计算**：结合用户每日目标热量，统计今日已摄入、剩余额度、蛋白质、脂肪、碳水。
- **饮食 Agent 问答**：支持“今天还能吃多少”“晚饭怎么安排”等场景化问答。
- **Token 使用统计**：记录每次 AI 调用的 prompt tokens、completion tokens、total tokens、耗时和是否 Mock。
- **可视化页面**：内置一个轻量级 Web 页面，启动后可直接体验核心流程。
- **可扩展大模型网关**：通过 `MimoAiClient` 预留 OpenAI-compatible API 调用逻辑。

---

## 技术栈

| 分类 | 技术 |
|---|---|
| 后端框架 | Spring Boot 3.3.x |
| 运行环境 | Java 17 |
| 接口开发 | Spring Web / Validation |
| 数据访问 | Spring JDBC |
| 数据库 | H2 内存数据库，附 MySQL 初始化脚本 |
| AI 接入 | OpenAI-compatible HTTP Client / Mock AI Fallback |
| 前端演示 | 原生 HTML + CSS + JavaScript |
| 项目管理 | Maven |

---

## 业务流程

```mermaid
flowchart TD
    A[用户上传餐食图片] --> B[AI 识别食物]
    B --> C[结构化解析菜品/克重/热量]
    C --> D[写入饮食记录]
    D --> E[统计今日摄入]
    E --> F[计算热量缺口]
    F --> G[Agent 生成健康建议]
    G --> H[记录 Token 使用情况]
```

---

## 快速启动

### 1. 克隆项目

```bash
git clone https://github.com/你的用户名/ai-diet-agent.git
cd ai-diet-agent
```

### 2. 本地运行

```bash
mvn spring-boot:run
```

启动成功后访问：

```text
http://localhost:8080
```

### 3. 查看 H2 控制台

```text
http://localhost:8080/h2-console
```

连接信息：

```text
JDBC URL: jdbc:h2:mem:diet_agent
User Name: sa
Password: 为空
```

---

## 真实模型调用配置

项目默认是 Mock AI，适合直接演示。如果需要接入真实模型，可以配置环境变量：

```bash
export MIMO_ENABLED=true
export MIMO_API_KEY=你的APIKey
export MIMO_BASE_URL=https://token-plan-cn.xiaomimimo.com/v1
export MIMO_MODEL=MiMo-V2.5
mvn spring-boot:run
```

Windows PowerShell：

```powershell
$env:MIMO_ENABLED="true"
$env:MIMO_API_KEY="你的APIKey"
$env:MIMO_BASE_URL="https://token-plan-cn.xiaomimimo.com/v1"
$env:MIMO_MODEL="MiMo-V2.5"
mvn spring-boot:run
```

---

## 主要接口

### AI 识别餐食

```http
POST /api/foods/recognize
Content-Type: application/json

{
  "userId": 10001,
  "mealType": "LUNCH",
  "imageUrl": "https://example.com/lunch.jpg",
  "remark": "米饭、鸡胸肉、青菜"
}
```

### 保存识别结果为饮食记录

```http
POST /api/records/from-recognition
Content-Type: application/json

{
  "userId": 10001,
  "mealType": "LUNCH",
  "foods": [
    {
      "name": "鸡胸肉",
      "weightGram": 150,
      "calorie": 248,
      "protein": 46.5,
      "fat": 5.4,
      "carbohydrate": 0
    }
  ]
}
```

### 查询今日看板

```http
GET /api/dashboard/today?userId=10001
```

### Agent 问答

```http
POST /api/agent/ask
Content-Type: application/json

{
  "userId": 10001,
  "question": "我今天晚上还能吃多少？"
}
```

### Token 使用统计

```http
GET /api/token-usage/summary?userId=10001
```

---

## 目录结构

```text
ai-diet-agent
├── docs
│   ├── API.md
│   ├── ARCHITECTURE.md
│   ├── PROJECT_INTRO.md
│   └── screenshots
├── sql
│   └── mysql_init.sql
├── src
│   ├── main
│   │   ├── java/com/example/dietagent
│   │   └── resources
│   └── test
├── pom.xml
├── README.md
└── .gitignore
```

---

## GitHub 上传命令

```bash
git init
git add .
git commit -m "init ai diet agent project"
git branch -M main
git remote add origin https://github.com/你的用户名/ai-diet-agent.git
git push -u origin main
```

---

## 项目声明

本项目用于 AI 应用开发学习和技术能力展示。默认 Mock 数据不代表真实医疗建议；实际健康管理场景需要结合专业营养知识、用户授权和数据合规要求。

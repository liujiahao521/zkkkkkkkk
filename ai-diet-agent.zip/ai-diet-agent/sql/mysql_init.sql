CREATE TABLE user_health_profile (
    user_id BIGINT PRIMARY KEY COMMENT '用户ID',
    nickname VARCHAR(50) NOT NULL COMMENT '昵称',
    gender VARCHAR(16) COMMENT '性别',
    height_cm DECIMAL(10,2) COMMENT '身高cm',
    weight_kg DECIMAL(10,2) COMMENT '当前体重kg',
    target_weight_kg DECIMAL(10,2) COMMENT '目标体重kg',
    daily_calorie_target DECIMAL(10,2) NOT NULL COMMENT '每日目标热量',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) COMMENT='用户健康档案表';

CREATE TABLE diet_record (
    id VARCHAR(64) PRIMARY KEY COMMENT '记录ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    meal_type VARCHAR(32) NOT NULL COMMENT '餐次',
    food_name VARCHAR(100) NOT NULL COMMENT '食物名称',
    weight_gram DECIMAL(10,2) NOT NULL COMMENT '重量g',
    calorie DECIMAL(10,2) NOT NULL COMMENT '热量kcal',
    protein DECIMAL(10,2) NOT NULL COMMENT '蛋白质g',
    fat DECIMAL(10,2) NOT NULL COMMENT '脂肪g',
    carbohydrate DECIMAL(10,2) NOT NULL COMMENT '碳水g',
    record_time DATETIME NOT NULL COMMENT '记录时间',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_record_time(user_id, record_time)
) COMMENT='饮食记录表';

CREATE TABLE token_usage_log (
    id VARCHAR(64) PRIMARY KEY COMMENT '日志ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    scene VARCHAR(64) NOT NULL COMMENT '调用场景',
    model_name VARCHAR(100) NOT NULL COMMENT '模型名称',
    prompt_tokens INT NOT NULL COMMENT '输入token',
    completion_tokens INT NOT NULL COMMENT '输出token',
    total_tokens INT NOT NULL COMMENT '总token',
    latency_ms BIGINT NOT NULL COMMENT '耗时ms',
    mock_flag TINYINT(1) NOT NULL COMMENT '是否mock',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_create_time(user_id, create_time)
) COMMENT='Token使用日志表';
